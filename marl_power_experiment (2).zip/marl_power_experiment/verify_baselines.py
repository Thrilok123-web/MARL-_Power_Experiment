"""Independent checks of the environment, WMMSE and exhaustive-search code used in Section IX (plain NumPy, no JAX in the checks)."""
import itertools, numpy as np, jax, jax.numpy as jnp
from marl_power import gen_layout, fading, sum_rate, exhaustive_best, wmmse_batch, LEV
rng = np.random.default_rng(123); out = []
def log(s): print(s); out.append(s)
def np_rate(H, noise, p):                          # explicit loop over links, float64
    N = len(p); tot = 0.0
    for i in range(N):
        interf = sum(H[i, j] * p[j] for j in range(N) if j != i)
        tot += np.log2(1 + H[i, i] * p[i] / (noise + interf))
    return tot
# 1. layout rule
ok = True; snr = []
for k in range(300):
    G, nz = gen_layout(jax.random.PRNGKey(k), 5); G = np.asarray(G, np.float64); nz = float(nz)
    l = 10 * np.diag(G) ** (-1 / 3)                              # recovered link distances
    ok &= bool(l.min() >= 8 - 1e-3 and l.max() <= 20 + 1e-3)
    ok &= abs(nz - np.mean(np.diag(G)) / 10 ** 2.5) < 1e-9 * max(1, nz)
    snr += list(10 * np.log10(np.diag(G) / nz))
log(f'1. layout rule: link distance in [8, 20] and noise = mean direct gain / 10^2.5 for 300 layouts: {ok}; direct-link SNR 5th-95th percentile {np.percentile(snr,5):.1f} to {np.percentile(snr,95):.1f} dB')
# 2. sum rate
G, nz = gen_layout(jax.random.PRNGKey(7), 5); H = np.asarray(fading(jax.random.PRNGKey(8), G, 200), np.float64); nzf = float(nz)
P = np.asarray(LEV)[rng.integers(0, 4, (200, 5))]
a = np.asarray(sum_rate(jnp.asarray(H, jnp.float32), jnp.full((200,), nz), jnp.asarray(P, jnp.float32)))
b = np.array([np_rate(H[i], nzf, P[i]) for i in range(200)])
log(f'2. sum rate, JAX vs explicit NumPy loop (200 draws): max relative difference {np.max(np.abs(a-b)/b):.2e}')
# 3. exhaustive search
for N, B in [(3, 50), (4, 30), (5, 10)]:
    G, nz = gen_layout(jax.random.PRNGKey(N), N); H = np.asarray(fading(jax.random.PRNGKey(N + 50), G, B), np.float64)
    ex = np.asarray(exhaustive_best(jnp.asarray(H, jnp.float32), jnp.full((B,), nz), N)); allv = list(itertools.product([0, .25, .5, 1.], repeat=N))
    bf = np.array([max(np_rate(H[i], float(nz), np.array(v)) for v in allv) for i in range(B)])
    log(f'3. exhaustive search N={N}: JAX vs NumPy brute force over {len(allv)} vectors, max relative difference {np.max(np.abs(ex-bf)/bf):.2e}')
# 4. fine grid versus WMMSE versus 4-level optimum (N = 3, 21 levels per link)
N = 3; G, nz = gen_layout(jax.random.PRNGKey(33), N); B = 100; H = np.asarray(fading(jax.random.PRNGKey(34), G, B), np.float64)
grid = np.linspace(0, 1, 21); V = np.array(list(itertools.product(grid, repeat=N)))
best = np.empty(B)
for i in range(B):
    inter = V @ H[i].T; sig = V * np.diag(H[i])[None]
    best[i] = np.log2(1 + sig / (float(nz) + inter - sig)).sum(1).max()
ex = np.asarray(exhaustive_best(jnp.asarray(H, jnp.float32), jnp.full((B,), nz), N))
p, its = wmmse_batch(H, np.full(B, float(nz)))
wm = np.array([np_rate(H[i], float(nz), p[i]) for i in range(B)])
log(f'4. N=3, {B} draws: 21-level fine grid >= 4-level optimum in all draws: {bool(np.all(best >= ex - 1e-4))}; mean 4-level/fine-grid = {np.mean(ex/best):.3f}; WMMSE/fine-grid mean {np.mean(wm/best):.3f}, max {np.max(wm/best):.3f}')
# 5. WMMSE monotone
H5 = np.asarray(fading(jax.random.PRNGKey(5), gen_layout(jax.random.PRNGKey(6), 5)[0], 100), np.float64); n5 = np.full(100, float(gen_layout(jax.random.PRNGKey(6), 5)[1]))
rates = []
for it in range(1, 9):
    pp, _ = wmmse_batch(H5, n5, tol=0, maxit=it); rates.append(np.mean([np_rate(H5[i], n5[i], pp[i]) for i in range(100)]))
log('5. WMMSE mean sum rate after 1..8 iterations (should not decrease): ' + ', '.join(f'{r:.3f}' for r in rates) + f'; non-decreasing: {all(np.diff(rates) > -1e-6)}')

# 6. WMMSE started from full power can stop at a poor stationary point on strongly coupled layouts; random restarts help
def wmmse_init(H, noise, v0, maxit=200, tol=1e-6):
    h = np.sqrt(H); v = v0.copy()
    for _ in range(maxit):
        den = noise + (H * (v ** 2)[None, :]).sum(1); u = np.diag(h) * v / den; w = 1 / (1 - u * np.diag(h) * v)
        vn = np.clip(w * u * np.diag(h) / ((w * u ** 2)[:, None] * H).sum(0), 0, 1)
        if np.abs(vn - v).max() < tol: v = vn; break
        v = vn
    return v ** 2
N = 3; G, nz = gen_layout(jax.random.PRNGKey(33), N); B = 100; H = np.asarray(fading(jax.random.PRNGKey(34), G, B), np.float64)
ex = np.asarray(exhaustive_best(jnp.asarray(H, jnp.float32), jnp.full((B,), nz), N)); p, its = wmmse_batch(H, np.full(B, float(nz)))
wm = np.array([np_rate(H[i], float(nz), p[i]) for i in range(B)]); rs = np.random.default_rng(0); multi = np.zeros(B)
for i in range(B):
    r = [np_rate(H[i], float(nz), wmmse_init(H[i], float(nz), rs.uniform(0.05, 1, N))) for _ in range(30)]; r.append(wm[i]); multi[i] = max(r)
log(f'6. WMMSE on a strongly coupled N=3 layout (cross-link gain 36 vs direct gain 1.3), 100 draws: single start at full power {np.mean(wm/ex):.3f} of the discrete optimum, best of 30 random restarts plus the full-power start {np.mean(multi/ex):.3f}')
open('verification_report.txt', 'w').write('\n'.join(out))
