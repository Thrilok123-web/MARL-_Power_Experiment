"""Runs every experiment of Section IX and writes results.json (incremental, resumable)."""
import json, os, sys, time, numpy as np, jax, jax.numpy as jnp
from marl_power import *
OUT = 'results.json'
R = json.load(open(OUT)) if os.path.exists(OUT) else {}
def save(): json.dump(R, open(OUT, 'w'))
METHODS = ['iql', 'vdn', 'qmix', 'mappo']
NS = [3, 5, 8]
def key(*a): return jax.random.PRNGKey(int(sum(x * 7919 ** i for i, x in enumerate(a))) % (2 ** 31))
def lay(N, kind, k):                     # kind: 0 train, 1 unseen, 2 tune
    G, nz = gen_layout(key(N, kind, k, 1), N)
    nreal = {0: 2000, 1: 1000, 2: 1000}[kind]
    H = fading(key(N, kind, k, 2), G, nreal)
    return G, nz, H, jnp.full((nreal,), nz)
log = lambda *a: print(time.strftime('%H:%M:%S'), *a, flush=True)

# ---- stage 1: references ----
if 'ref' not in R:
    R['ref'] = {}
    for N in NS:
        R['ref'][N] = {'train': [], 'unseen': [], 'tune': None}
        for kind, name, ks in [(0, 'train', [1, 2, 3]), (1, 'unseen', [1, 2, 3, 4, 5]), (2, 'tune', [1])]:
            for k in ks:
                G, nz, H, nzv = lay(N, kind, k)
                ref = references(G, nz, H, N, key(N, kind, k, 3))
                if name == 'tune': R['ref'][N]['tune'] = ref
                else: R['ref'][N][name].append(ref)
                log('ref', N, name, k, {a: round(b, 3) for a, b in ref.items()})
    save()
def REF(N): return R['ref'][str(N)] if str(N) in R['ref'] else R['ref'][N]

# ---- stage 2: per-N, per-method learning-rate selection ----
if 'tune' not in R:
    R['tune'] = {}
    for N in NS:
        G, nz, H, nzv = lay(N, 2, 1); opt = REF(N)['tune']['opt']
        for m in METHODS:
            sc = {}
            for lr in LR_GRID:
                v = []
                for s in range(2):
                    p, c = train(key(N, 9, s, 4), lr, G, nz, H, nzv, opt, m, N, 'full', False)
                    v.append(float(c[-1]))
                sc[str(lr)] = float(np.mean(v)); 
            best = max(sc, key=sc.get)
            R['tune'][f'{N}_{m}'] = dict(scores=sc, best=float(best))
            log('tune', N, m, best, {k: round(v * 100, 1) for k, v in sc.items()})
        save()

# ---- stage 3/4: main runs (full observation) and local-observation variant ----
def run_block(N, omode, tag):
    ref = REF(N); unseen = [lay(N, 1, k) for k in range(1, 6)]
    tr = [lay(N, 0, k) for k in range(1, 4)]
    runs = []
    for m in METHODS:
        lr = R['tune'][f'{N}_{m}']['best']
        for L in range(3):
            G, nz, H, nzv = tr[L]; opt = ref['train'][L]['opt']
            for s in range(4):
                p, c = train(key(N, 20 + L, s, 5), lr, G, nz, H, nzv, opt, m, N, omode, False)
                se_in = float(evaluate(p, H, nzv, m, N, omode))
                se_un = [float(evaluate(p, Hu, nzu, m, N, omode)) for (_, _, Hu, nzu) in unseen]
                runs.append(dict(method=m, mode='single', layout=L, seed=s, lr=lr,
                                 inl=se_in / opt, inl_full=ref['train'][L]['full'] / opt,
                                 unseen=float(np.mean([a / r['opt'] for a, r in zip(se_un, ref['unseen'])])),
                                 unseen_full=float(np.mean([r['full'] / r['opt'] for r in ref['unseen']])),
                                 curve=[float(x) for x in c]))
        for s in range(8):
            p, c = train(key(N, 30, s, 6), lr, tr[0][0], tr[0][1], tr[0][2], tr[0][3], 1.0, m, N, omode, True)
            se_un = [float(evaluate(p, Hu, nzu, m, N, omode)) for (_, _, Hu, nzu) in unseen]
            runs.append(dict(method=m, mode='multi', layout=-1, seed=s, lr=lr,
                             unseen=float(np.mean([a / r['opt'] for a, r in zip(se_un, ref['unseen'])])),
                             unseen_full=float(np.mean([r['full'] / r['opt'] for r in ref['unseen']]))))
        log(tag, N, m, 'done')
    R[tag + f'_{N}'] = runs; save()

for N in NS:
    if f'main_{N}' not in R: run_block(N, 'full', 'main')
for N in [5, 8]:
    if f'local_{N}' not in R: run_block(N, 'local', 'local')
log('ALL DONE')
