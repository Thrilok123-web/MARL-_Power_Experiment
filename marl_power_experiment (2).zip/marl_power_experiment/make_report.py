import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
R=json.load(open('results.json'))
M=['iql','vdn','qmix','mappo']; NAME={'iql':'IQL','vdn':'VDN','qmix':'QMIX','mappo':'MAPPO'}
def pct(x): return 100*np.asarray(x)
def cell(vals,fails): 
    v=pct(vals); q1,md,q3=np.percentile(v,[25,50,75]); return f'{md:.1f} [{q1:.1f}–{q3:.1f}] ({fails})'
def learner_cells(runs,m):
    s=[r for r in runs if r['method']==m and r['mode']=='single']; mu=[r for r in runs if r['method']==m and r['mode']=='multi']
    return (cell([r['inl'] for r in s],sum(r['inl']<r['inl_full'] for r in s)),
            cell([r['unseen'] for r in s],sum(r['unseen']<r['unseen_full'] for r in s)),
            cell([r['unseen'] for r in mu],sum(r['unseen']<r['unseen_full'] for r in mu)))
def base(N):
    ref=R['ref'][str(N)]; out={}
    for key,name in [('wmmse','WMMSE (continuous power)'),('wmmse_q','WMMSE (quantised to the four levels)'),('full','Full power'),('rand','Random power levels')]:
        row=[]
        for part in ('train','unseen'):
            v=pct([r[key]/r['opt'] for r in ref[part]]); row.append(f'{np.median(v):.1f} [{v.min():.1f}–{v.max():.1f}]')
        out[name]=row
    it_tr=np.mean([r['wmmse_iters'] for r in ref['train']]); it_un=np.mean([r['wmmse_iters'] for r in ref['unseen']])
    meanopt=np.mean([r['opt'] for r in ref['train']])
    return out,it_tr,it_un,meanopt
T={}
for N in (3,5,8):
    if f'main_{N}' not in R: continue
    runs=R[f'main_{N}']; b,it_tr,it_un,mo=base(N)
    T[N]=dict(base=b,iters=it_tr,iters_un=it_un,meanopt=mo,msgs=N*(N-1)*it_tr,csi=N*(N-1),
              learners={NAME[m]:learner_cells(runs,m) for m in M},lr={NAME[m]:R['tune'][f'{N}_{m}']['best'] for m in M})
    if f'local_{N}' in R: T[N]['local']={NAME[m]:learner_cells(R[f'local_{N}'],m) for m in M}
json.dump(T,open('tables.json','w'),indent=1)
for N in T:
    print('N',N,'meanopt',round(T[N]['meanopt'],2),'iters',round(T[N]['iters'],1),'msgs',round(T[N]['msgs']),'csi',T[N]['csi'],'lr',T[N]['lr'])
    for k,v in T[N]['base'].items(): print('  ',k,v)
    for k,v in T[N]['learners'].items(): print('  ',k,v)
    for k,v in T[N].get('local',{}).items(): print('  local',k,v)
# ---- Figure 5 ----
col={'iql':'#1f77b4','vdn':'#2ca02c','qmix':'#d62728','mappo':'#9467bd'}
fig,ax=plt.subplots(1,2,figsize=(7,2.82),dpi=300,gridspec_kw={'width_ratios':[1,1.25]})
runs=R['main_5']; x=np.arange(100,2001,100)
for m in M:
    c=np.array([r['curve'] for r in runs if r['method']==m and r['mode']=='single'])*100
    q1,md,q3=np.percentile(c,[25,50,75],axis=0)
    ax[0].plot(x,md,color=col[m],lw=1.2,label=NAME[m]); ax[0].fill_between(x,q1,q3,color=col[m],alpha=.15,lw=0)
ref=R['ref']['5']; ax[0].axhline(100*np.median([r['wmmse']/r['opt'] for r in ref['train']]),color='k',ls='--',lw=.8,label='WMMSE')
ax[0].axhline(100*np.mean([r['full']/r['opt'] for r in ref['train']]),color='gray',ls='-.',lw=.8,label='Full power')
ax[0].set_xlabel('Training iteration',fontsize=7); ax[0].set_ylabel('% of discrete optimum',fontsize=7); ax[0].set_title('(a) N = 5, in-layout',fontsize=7)
ax[0].legend(fontsize=5.5,ncol=2,loc='lower right',frameon=False); ax[0].tick_params(labelsize=6); ax[0].set_ylim(40,102)
rng=np.random.default_rng(0); pos=0; ticks=[]; labs=[]
for N in (5,8):
    runs=R[f'main_{N}']; fl=100*np.mean([r['inl_full'] for r in runs if r['method']=='iql' and r['mode']=='single'])
    start=pos
    for m in M:
        s=[r for r in runs if r['method']==m and r['mode']=='single']
        v=np.array([r['inl'] for r in s])*100; bad=np.array([r['inl']<r['inl_full'] for r in s])
        xs=pos+rng.uniform(-.18,.18,len(v))
        ax[1].scatter(xs[~bad],v[~bad],s=7,color=col[m]); ax[1].scatter(xs[bad],v[bad],s=14,marker='x',color='k',lw=.8)
        ax[1].hlines(np.median(v),pos-.3,pos+.3,color=col[m],lw=1.6); ticks.append(pos); labs.append(NAME[m]); pos+=1
    ax[1].hlines(fl,start-.5,pos-.5,color='gray',ls='-.',lw=.8); ax[1].text((start+pos-1)/2,32,f'N = {N}',ha='center',fontsize=6.5); pos+=1
ax[1].set_xticks(ticks); ax[1].set_xticklabels(labs,fontsize=5.5,rotation=45); ax[1].set_ylim(25,102)
ax[1].set_ylabel('% of discrete optimum',fontsize=7); ax[1].set_title('(b) final in-layout result of every run',fontsize=7); ax[1].tick_params(labelsize=6)
plt.tight_layout(); plt.savefig('fig5_new.png'); print('fig saved')
