"""Worked example of Section IX: cooperative power control as a multi-agent contextual bandit.
Methods: IQL, VDN, QMIX, MAPPO (parameter sharing, team reward) versus full power, random levels,
WMMSE (continuous and quantised) and exhaustive search over the 4^N discrete power vectors.
Python 3, JAX (CPU). All randomness is seeded; every result is written to JSON by run_all.py."""
import itertools, functools, numpy as np, jax, jax.numpy as jnp
LEV = jnp.array([0., .25, .5, 1.])
ITERS, BATCH, HID, EMB = 2000, 256, 64, 32
LR_GRID = [1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2]

# ---------------- environment ----------------
def gen_layout(key, N):
    k1, k2, k3 = jax.random.split(key, 3)
    tx = jax.random.uniform(k1, (N, 2)) * 35.
    l = jax.random.uniform(k2, (N,), minval=8., maxval=20.)
    th = jax.random.uniform(k3, (N,)) * 2 * jnp.pi
    rx = tx + jnp.stack([l * jnp.cos(th), l * jnp.sin(th)], -1)
    D = jnp.linalg.norm(rx[:, None, :] - tx[None, :, :], axis=-1)      # D[i,j] = |rx_i - tx_j|
    G = (D / 10.) ** -3
    return G, jnp.mean(jnp.diag(G)) / 10 ** 2.5

def fading(key, G, B):
    return G[None] * jax.random.exponential(key, (B,) + G.shape)

def sum_rate(H, noise, p):                                # H (B,N,N), noise (B,), p (B,N)
    S = H * p[:, None, :]
    sig = jnp.diagonal(S, axis1=1, axis2=2)
    sinr = sig / (noise[:, None] + S.sum(-1) - sig)
    return jnp.log2(1 + sinr).sum(-1)

def obs_full(H, noise, N):
    L = jnp.log10(jnp.maximum(H, 1e-20) / noise[:, None, None]) / 3.
    ar = jnp.arange(N)
    off = jnp.array([[j for j in range(N) if j != i] for i in range(N)])
    direct = L[:, ar, ar][..., None]
    inc = L[:, ar[:, None], off]                           # gains from other transmitters to my receiver
    out = L[:, off, ar[:, None]]                           # gains from my transmitter to other receivers
    eye = jnp.broadcast_to(jnp.eye(N), (H.shape[0], N, N))
    return jnp.concatenate([direct, inc, out, eye], -1)

def obs_local(H, noise, N):                                # own gain + interference measured with all others at full power
    ar = jnp.arange(N)
    d = H[:, ar, ar]
    I = H.sum(-1) - d
    eye = jnp.broadcast_to(jnp.eye(N), (H.shape[0], N, N))
    return jnp.concatenate([(jnp.log10(jnp.maximum(d, 1e-20) / noise[:, None]) / 3.)[..., None],
                            (jnp.log10(jnp.maximum(I, 1e-20) / noise[:, None]) / 3.)[..., None], eye], -1)

def state_of(H, noise):
    return (jnp.log10(jnp.maximum(H, 1e-20) / noise[:, None, None]) / 3.).reshape(H.shape[0], -1)

def obs_dim(N, mode): return (3 * N - 1) if mode == 'full' else (2 + N)

# ---------------- networks ----------------
def init_mlp(key, sizes):
    ps = []
    for k, (a, b) in zip(jax.random.split(key, len(sizes) - 1), zip(sizes[:-1], sizes[1:])):
        ps.append((jax.random.normal(k, (a, b)) * jnp.sqrt(2. / a), jnp.zeros(b)))
    W, b = ps[-1]; ps[-1] = (W * 0.1, b)
    return ps
def mlp(ps, x):
    for W, b in ps[:-1]: x = jax.nn.relu(x @ W + b)
    W, b = ps[-1]; return x @ W + b
def lin(p, x): return x @ p[0] + p[1]

def init_params(key, method, N, omode):
    ks = jax.random.split(key, 6); od = obs_dim(N, omode); S = N * N
    if method in ('iql', 'vdn'): return {'q': init_mlp(ks[0], [od, HID, HID, 4])}
    if method == 'qmix':
        return {'q': init_mlp(ks[0], [od, HID, HID, 4]),
                'hw1': init_mlp(ks[1], [S, N * EMB])[0], 'hb1': init_mlp(ks[2], [S, EMB])[0],
                'hw2': init_mlp(ks[3], [S, EMB])[0], 'hb2': init_mlp(ks[4], [S, EMB, 1])}
    return {'pi': init_mlp(ks[0], [od, HID, HID, 4]), 'v': init_mlp(ks[1], [S, HID, HID, 1])}

def mix(p, q, s, N):
    w1 = jnp.abs(lin(p['hw1'], s)).reshape(-1, N, EMB); b1 = lin(p['hb1'], s)
    h = jax.nn.elu(jnp.einsum('bn,bne->be', q, w1) + b1)
    return (h * jnp.abs(lin(p['hw2'], s))).sum(-1) + mlp(p['hb2'], s)[..., 0]

def vloss(params, obs, st, a, r, method, N):
    q = mlp(params['q'], obs)
    qa = jnp.take_along_axis(q, a[..., None], -1)[..., 0]
    if method == 'iql': return ((qa - r[:, None]) ** 2).mean()
    if method == 'vdn': return ((qa.sum(-1) - r) ** 2).mean()
    return ((mix(params, qa, st, N) - r) ** 2).mean()

def ppo_loss(params, obs, st, a, r, logp_old, adv):
    logits = mlp(params['pi'], obs); lp = jax.nn.log_softmax(logits)
    logp = jnp.take_along_axis(lp, a[..., None], -1)[..., 0]
    ratio = jnp.exp(logp - logp_old); A = adv[:, None]
    pg = -jnp.minimum(ratio * A, jnp.clip(ratio, .8, 1.2) * A).mean()
    ent = -(jnp.exp(lp) * lp).sum(-1).mean()
    vl = 0.5 * ((mlp(params['v'], st)[..., 0] - r) ** 2).mean()
    return pg + vl - 0.01 * ent

def adam(params, g, m, v, t, lr):
    m = jax.tree_util.tree_map(lambda m_, g_: .9 * m_ + .1 * g_, m, g)
    v = jax.tree_util.tree_map(lambda v_, g_: .999 * v_ + .001 * g_ ** 2, v, g)
    c1, c2 = 1 - .9 ** t, 1 - .999 ** t
    params = jax.tree_util.tree_map(lambda p, m_, v_: p - lr * (m_ / c1) / (jnp.sqrt(v_ / c2) + 1e-8), params, m, v)
    return params, m, v

def greedy(params, method, obs):
    return jnp.argmax(mlp(params['pi' if method == 'mappo' else 'q'], obs), -1)

def eval_policy(params, method, N, omode, H, noise):
    of = obs_full if omode == 'full' else obs_local
    a = greedy(params, method, of(H, noise, N))
    return sum_rate(H, noise, LEV[a]).mean()

# ---------------- training ----------------
@functools.partial(jax.jit, static_argnames=('method', 'N', 'omode', 'multi', 'iters'))
def train(key, lr, G_fixed, noise_fixed, Heval, noise_eval, opt_eval, method, N, omode, multi, iters=ITERS):
    of = obs_full if omode == 'full' else obs_local
    k0, key = jax.random.split(key)
    params = init_params(k0, method, N, omode)
    m = jax.tree_util.tree_map(jnp.zeros_like, params); v = jax.tree_util.tree_map(jnp.zeros_like, params)
    chunk = 100; nchunk = iters // chunk

    def sample(key):
        k1, k2 = jax.random.split(key)
        if multi:
            G, nz = jax.vmap(lambda k: gen_layout(k, N))(jax.random.split(k1, BATCH))
            H = G * jax.random.exponential(k2, (BATCH, N, N))
        else:
            H = fading(k2, G_fixed, BATCH); nz = jnp.full((BATCH,), noise_fixed)
        return H, nz

    def step(carry, t):
        params, m, v, key, cnt = carry
        key, ks, ka, ke, kp = jax.random.split(key, 5)
        H, nz = sample(ks)
        obs, st = of(H, nz, N), state_of(H, nz)
        if method == 'mappo':
            logits = mlp(params['pi'], obs)
            a = jax.random.categorical(ka, logits)
            r = sum_rate(H, nz, LEV[a])
            lp = jax.nn.log_softmax(logits)
            logp_old = jnp.take_along_axis(lp, a[..., None], -1)[..., 0]
            adv = r - mlp(params['v'], st)[..., 0]
            adv = (adv - adv.mean()) / (adv.std() + 1e-8)
            def ep(c, _):
                params, m, v, cnt = c
                g = jax.grad(ppo_loss)(params, obs, st, a, r, logp_old, adv)
                cnt = cnt + 1
                params, m, v = adam(params, g, m, v, cnt, lr)
                return (params, m, v, cnt), None
            (params, m, v, cnt), _ = jax.lax.scan(ep, (params, m, v, cnt), None, length=4)
        else:
            eps = jnp.maximum(0.05, 1 - 0.95 * t / (0.6 * iters))
            q = mlp(params['q'], obs)
            ag = jnp.argmax(q, -1)
            ar_ = jax.random.randint(ka, ag.shape, 0, 4)
            a = jnp.where(jax.random.uniform(ke, ag.shape) < eps, ar_, ag)
            r = sum_rate(H, nz, LEV[a])
            g = jax.grad(vloss)(params, obs, st, a, r, method, N)
            cnt = cnt + 1
            params, m, v = adam(params, g, m, v, cnt, lr)
        return (params, m, v, key, cnt), None

    def chunk_fn(carry, c):
        carry, _ = jax.lax.scan(step, carry, c * chunk + jnp.arange(chunk))
        val = eval_policy(carry[0], method, N, omode, Heval, noise_eval) / opt_eval
        return carry, val

    carry = (params, m, v, key, jnp.array(0, jnp.int32))
    carry, curve = jax.lax.scan(chunk_fn, carry, jnp.arange(nchunk))
    return carry[0], curve

@functools.partial(jax.jit, static_argnames=('method', 'N', 'omode'))
def evaluate(params, H, noise, method, N, omode):
    return eval_policy(params, method, N, omode, H, noise)

# ---------------- reference methods ----------------
def wmmse_batch(H, noise, tol=1e-4, maxit=100):
    """Distributed-style WMMSE (Shi et al., 2011) for the SISO interference channel, Pmax = 1.
    Returns continuous powers (B,N) and the iteration count per realization."""
    H = np.asarray(H, np.float64); noise = np.asarray(noise, np.float64)
    B, N, _ = H.shape; h = np.sqrt(H); hd = np.diagonal(h, axis1=1, axis2=2)
    v = np.ones((B, N)); nz = noise[:, None]
    def rate(v):
        S = H * (v ** 2)[:, None, :]; sig = np.diagonal(S, axis1=1, axis2=2)
        return np.log2(1 + sig / (nz + S.sum(-1) - sig)).sum(-1)
    Rold = rate(v); its = np.zeros(B); act = np.ones(B, bool)
    for _ in range(maxit):
        den = nz + (H * (v ** 2)[:, None, :]).sum(-1)
        u = hd * v / den
        w = 1. / (1. - u * hd * v)
        num = w * u * hd
        dd = (w * u ** 2)[:, :, None] * H                  # dd[b,j,i] = w_j u_j^2 |h_ji|^2 (receiver j, transmitter i)
        vnew = np.clip(num / dd.sum(1), 0, 1.)
        v = np.where(act[:, None], vnew, v)
        its += act
        R = rate(v); act = act & (np.abs(R - Rold) > tol); Rold = R
        if not act.any(): break
    return v ** 2, its

def exhaustive_best(H, noise, N, chunk=32):
    P = jnp.array(list(itertools.product([0., .25, .5, 1.], repeat=N)))        # (4^N, N)
    def one(args):
        Hb, nb = args
        inter = P @ Hb.T; sig = P * jnp.diagonal(Hb)[None]
        return jnp.log2(1 + sig / (nb + inter - sig)).sum(-1).max()
    return jax.lax.map(one, (H, noise), batch_size=chunk)

def references(G, nz, H, N, key):
    B = H.shape[0]; noise = jnp.full((B,), nz)
    full = float(sum_rate(H, noise, jnp.ones((B, N))).mean())
    rnd = float(sum_rate(H, noise, LEV[jax.random.randint(key, (B, N), 0, 4)]).mean())
    opt = float(exhaustive_best(H, noise, N).mean())
    p, its = wmmse_batch(np.asarray(H), np.asarray(noise))
    wm = float(sum_rate(H, noise, jnp.asarray(p, jnp.float32)).mean())
    pq = jnp.asarray(np.abs(p[..., None] - np.array([0, .25, .5, 1.])).argmin(-1), jnp.int32)
    wq = float(sum_rate(H, noise, LEV[pq]).mean())
    return dict(opt=opt, wmmse=wm, wmmse_q=wq, full=full, rand=rnd, wmmse_iters=float(its.mean()))
