# Worked example of Section IX: MARL power control versus WMMSE

Files
- marl_power.py  environment, IQL / VDN / QMIX / MAPPO, WMMSE, exhaustive search (Python 3, JAX, CPU)
- run_all.py     runs every experiment and writes results.json (resumable; stages: references, learning-rate tuning, main runs, local-observation runs)
- make_report.py reads results.json, writes tables.json and the figure
- results.json   raw output: references per layout, tuning scores, every run (method, layout, seed, learning rate, in-layout and unseen results, training curve)
- tables.json, fig5_new.png  derived tables and Fig. 5
- verify_baselines.py, verification_report.txt  independent NumPy checks of the environment, sum rate, WMMSE and exhaustive search (run: python verify_baselines.py)

Reproduce
    pip install jax jaxlib numpy matplotlib
    python run_all.py      # about 90 minutes on one CPU core (about 15 minutes of that is the exhaustive-search and WMMSE references and tuning)
    python make_report.py

Seeds are fixed in run_all.py (function key()). Layout rule: transmitters uniform in a 35 x 35 area, receiver at distance U(8, 20) in a random direction,
path-loss exponent 3 with reference distance 10, Rayleigh fading power (unit-mean exponential), noise = mean direct path-loss gain / 10^2.5.
Power levels {0, 0.25, 0.5, 1}; reward = sum of log2(1 + SINR). Hyperparameters are listed in Section IX-A of the manuscript.
